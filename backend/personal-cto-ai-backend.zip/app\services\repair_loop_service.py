
import os

from app.services.validator_service import ValidatorService
from app.agents.repair_agent import RepairAgent
from app.graphs.repair_graph import (
    repair_graph
)


class RepairLoopService:

    MAX_REPAIR_ATTEMPTS = 3

    @staticmethod
    def _load_project_files(project_folder: str):

        files = {}

        for root, _, filenames in os.walk(project_folder):

            for filename in filenames:

                if not filename.endswith(".py"):
                    continue

                file_path = os.path.join(root, filename)

                relative_path = os.path.relpath(
                    file_path,
                    project_folder
                )

                with open(
                    file_path,
                    "r",
                    encoding="utf-8"
                ) as f:
                    files[relative_path] = f.read()

        return files

    @staticmethod
    def _apply_fixes(
        project_folder: str,
        repaired_files: list
    ):

        for file_data in repaired_files:

            file_path = file_data.get("file_path")

            code = file_data.get("code")

            if not file_path or not code:
                continue

            full_path = os.path.join(
                project_folder,
                file_path
            )

            os.makedirs(
                os.path.dirname(full_path),
                exist_ok=True
            )

            with open(
                full_path,
                "w",
                encoding="utf-8"
            ) as f:
                f.write(code)

    @classmethod
    def execute(
        cls,
        project_folder: str
    ):

        for attempt in range(
            cls.MAX_REPAIR_ATTEMPTS
        ):

            report = (
                ValidatorService.validate_project(
                    project_folder
                )
            )

            if report.success:

                return {
                    "success": True,
                    "attempts": attempt,
                    "report": report.model_dump()
                }

            files = cls._load_project_files(
                project_folder
            )

            repair_result = (
                RepairAgent.execute(
                    validation_report=
                    report.model_dump(),

                    file_contents=files
                )
            )

            cls._apply_fixes(
                project_folder,
                repair_result.get(
                    "files",
                    []
                )
            )

        final_report = (
            ValidatorService.validate_project(
                project_folder
            )
        )

        return {
            "success": False,
            "attempts":
                cls.MAX_REPAIR_ATTEMPTS,
            "report":
                final_report.model_dump()
        }